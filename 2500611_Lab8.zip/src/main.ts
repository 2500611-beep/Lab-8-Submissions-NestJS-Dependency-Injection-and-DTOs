// Name: YOUR NAME HERE | Reg. No: YOUR REG NO HERE
// Entry point: starts the app and turns on ValidationPipe globally.
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,            // strip unknown properties
      forbidNonWhitelisted: true, // extra field => 400
      transform: true,            // convert payloads/query to DTO types
    }),
  );

  await app.listen(3000);
  console.log('Library API running on http://localhost:3000');
}
bootstrap();
