// Name: YOUR NAME HERE | Reg. No: YOUR REG NO HERE
// LoggerService: a simple provider that prints one line per action.
import { Injectable } from '@nestjs/common';

@Injectable()
export class LoggerService {
  log(message: string): void {
    console.log(`[${new Date().toISOString()}] ${message}`);
  }
}
