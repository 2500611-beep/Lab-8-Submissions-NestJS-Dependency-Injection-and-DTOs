// Name: YOUR NAME HERE | Reg. No: YOUR REG NO HERE
// BooksController: defines the routes. Gets BooksService by constructor injection.
import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put, Query } from '@nestjs/common';
import { BooksService } from './books.service';
import { CreateBookDto } from './dto/create-book.dto';
import { UpdateBookDto } from './dto/update-book.dto';

@Controller('books')
export class BooksController {
  constructor(private readonly booksService: BooksService) {}

  // GET /books or GET /books?available=true
  @Get()
  findAll(@Query('available') available?: string) {
    const filter = available === undefined ? undefined : available === 'true';
    return this.booksService.findAll(filter);
  }

  // NOTE: 'search' must be declared before ':id' so it is not treated as an id.
  @Get('search')
  search(@Query('title') title: string) {
    return this.booksService.search(title);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.booksService.findOne(id);
  }

  // POST returns 201 by default
  @Post()
  create(@Body() dto: CreateBookDto) {
    return this.booksService.create(dto);
  }

  // Bonus: borrow a book
  @Put(':id/borrow')
  borrow(@Param('id', ParseIntPipe) id: number) {
    return this.booksService.borrow(id);
  }

  @Put(':id')
  update(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateBookDto) {
    return this.booksService.update(id, dto);
  }

  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.booksService.remove(id);
  }
}
