// Name: YOUR NAME HERE | Reg. No: YOUR REG NO HERE
// Shape of a book stored in memory.
export interface Book {
  id: number;
  title: string;
  author: string;
  year: number;
  available: boolean;
}
