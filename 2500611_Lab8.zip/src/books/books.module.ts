// Name: YOUR NAME HERE | Reg. No: YOUR REG NO HERE
// BooksModule: registers controller + providers (LoggerService and the LIBRARY_CONFIG value provider).
import { Module } from '@nestjs/common';
import { BooksController } from './books.controller';
import { BooksService } from './books.service';
import { LoggerService } from '../logger/logger.service';
import { LIBRARY_CONFIG, libraryConfigValue } from './books.constants';

@Module({
  controllers: [BooksController],
  providers: [
    BooksService,
    LoggerService,
    { provide: LIBRARY_CONFIG, useValue: libraryConfigValue },
  ],
})
export class BooksModule {}
