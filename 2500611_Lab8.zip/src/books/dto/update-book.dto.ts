// Name: YOUR NAME HERE | Reg. No: YOUR REG NO HERE
// DTO used for PUT /books/:id. Same rules as CreateBookDto, but every field is optional.
import { IsBoolean, IsInt, IsNotEmpty, IsOptional, IsString, Max, Min } from 'class-validator';

export class UpdateBookDto {
  @IsOptional()
  @IsString()
  @IsNotEmpty()
  title?: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  author?: string;

  @IsOptional()
  @IsInt()
  @Min(1900)
  @Max(2026)
  year?: number;

  @IsOptional()
  @IsBoolean()
  available?: boolean;
}
