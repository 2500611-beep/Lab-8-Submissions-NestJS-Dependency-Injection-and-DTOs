// Name: YOUR NAME HERE | Reg. No: YOUR REG NO HERE
// Root module: imports the BooksModule.
import { Module } from '@nestjs/common';
import { BooksModule } from './books/books.module';

@Module({
  imports: [BooksModule],
})
export class AppModule {}
